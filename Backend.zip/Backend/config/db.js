// config/db.js
const { Pool } = require('pg');
const dotenv = require('dotenv');

// Make sure environment variables are loaded
dotenv.config();

// For debugging - remove this in production
console.log('DB_USER:', process.env.DB_USER);
console.log('DB_HOST:', process.env.DB_HOST);
console.log('DB_NAME:', process.env.DB_NAME);
console.log('DB_PORT:', process.env.DB_PORT);
console.log('DB_PASSWORD type:', typeof process.env.DB_PASSWORD);
// Don't log the actual password value for security reasons

const pool = new Pool({
  user: process.env.DB_USER || 'postgres',
  host: process.env.DB_HOST || 'localhost',
  database: process.env.DB_NAME || 'signup_app',
  password: String(process.env.DB_PASSWORD), // Ensure password is a string
  port: parseInt(process.env.DB_PORT || '5432')
});

const initDb = async () => {
  try {
    // Test the connection
    const client = await pool.connect();
    console.log('PostgreSQL connected successfully');
    client.release();
    
    // Create tables if they don't exist
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(100) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `);
    console.log('Database tables initialized successfully');
    return true;
  } catch (error) {
    console.error('Database connection error:', error);
    return false;
  }
};

module.exports = { pool, initDb };