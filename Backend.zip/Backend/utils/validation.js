const validateSignup = (name, email, password) => {
    if (!name || !email || !password) {
      return 'All fields are required';
    }
    
    if (name.length < 2) {
      return 'Name must be at least 2 characters';
    }
    
    if (!isValidEmail(email)) {
      return 'Please provide a valid email address';
    }
    
    if (password.length < 6) {
      return 'Password must be at least 6 characters';
    }
    
    return null;
  };
  
  const validateSignin = (email, password) => {
    if (!email || !password) {
      return 'Email and password are required';
    }
    
    if (!isValidEmail(email)) {
      return 'Please provide a valid email address';
    }
    
    return null;
  };
  
  const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };
  
  module.exports = { validateSignup, validateSignin };
  