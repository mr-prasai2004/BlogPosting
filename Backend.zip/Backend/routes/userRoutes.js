const express = require('express');
const { signupUser, signinUser, getUserProfile } = require('../controllers/userController');
const { protect } = require('../middleware/authMiddleware');

const router = express.Router();

router.post('/signup', signupUser);
router.post('/signin', signinUser);
router.get('/profile', protect, getUserProfile);

module.exports = router;
