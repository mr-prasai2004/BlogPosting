const express = require('express');
const router = express.Router();
const blogController = require('../controllers/blogController');
const authMiddleware = require('../middleware/auth');
const pool = require('../config/db'); // ✅ Import database pool

router.post('/create', authMiddleware, async (req, res) => {  // ✅ Add authMiddleware
  try {
    const { title, content, tags } = req.body;
    const userId = req.user.id; // ✅ Ensure userId is passed

    // Validate input
    if (!title || !content) {
      return res.status(400).json({ message: 'Title and content are required' });
    }

    // SQL Insert Statement using `pool` instead of `connection`
    const query = 'INSERT INTO blogs (title, content, tags, user_id) VALUES (?, ?, ?, ?)';
    const [result] = await pool.execute(query, [
      title, 
      content, 
      tags || null,  // Handle optional tags
      userId
    ]);

    res.status(201).json({
      success: true,
      data: {
        id: result.insertId,
        title,
        content,
        tags
      }
    });
  } catch (error) {
    console.error('Error creating blog post:', error);
    res.status(500).json({ 
      message: 'Failed to create blog post', 
      error: error.message 
    });
  }
});

// Remove duplicate POST route
// router.post('/', authMiddleware, blogController.createBlog);

module.exports = router;
