const jwt = require('jsonwebtoken');
const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
  try {
    // Try to get token from Authorization header (Bearer token)
    let token = req.header('Authorization');

    if (!token) {
      return res.status(401).json({ message: 'No token, authorization denied' });
    }

    // If token follows 'Bearer <token>' format, extract the actual token
    if (token.startsWith('Bearer ')) {
      token = token.split(' ')[1];
    }

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Add user from payload
    req.user = decoded.user;
    next();
  } catch (err) {
    res.status(401).json({ message: 'Token is not valid' });
  }
};
