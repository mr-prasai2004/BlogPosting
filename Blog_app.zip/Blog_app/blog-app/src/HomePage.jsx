import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, User, BookOpen, PenTool } from 'lucide-react';


const BlogCard = ({ title, excerpt, author, date, imageUrl }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 hover:shadow-xl">
      <img 
        src={imageUrl || '/api/placeholder/800/400'} 
        alt={title} 
        className="w-full h-48 object-cover"
      />
      <div className="p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">{title}</h2>
        <p className="text-gray-600 mb-4">{excerpt}</p>
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <img 
              src="/api/placeholder/40/40" 
              alt={author} 
              className="w-10 h-10 rounded-full"
            />
            <div>
              <p className="text-sm font-medium text-gray-700">{author}</p>
              <p className="text-xs text-gray-500">{date}</p>
            </div>
          </div>
          <Link 
            to={`/blog/${title.toLowerCase().replace(/\s+/g, '-')}`}
            className="text-blue-500 hover:text-blue-700 flex items-center"
          >
            Read More <BookOpen className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </div>
    </div>
  );
};

const Navbar = () => {
  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold text-gray-800">BlogSpace</Link>
        
        <div className="flex items-center space-x-6">
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search blogs..." 
              className="pl-10 pr-4 py-2 border rounded-full w-64 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <Search className="absolute left-3 top-3 text-gray-400" />
          </div>
          
          <div className="flex items-center space-x-4">
            <Link to="/create" className="text-gray-700 hover:text-blue-500 flex items-center">
              <PenTool className="mr-2" /> Write
            </Link>
            <Link to="/signin" className="text-gray-700 hover:text-blue-500 flex items-center">
              <User className="mr-2" /> Sign In
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

const HomePage = () => {
  const [blogs, setBlogs] = useState([
    {
      id: 1,
      title: "The Future of Web Development",
      excerpt: "Exploring the latest trends and technologies shaping the web development landscape...",
      author: "John Doe",
      date: "March 5, 2024",
      imageUrl: "https://plus.unsplash.com/premium_photo-1678565879444-f87c8bd9f241?q=80&w=2940&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
    },
    {
      id: 2,
      title: "React 19: What's New?",
      excerpt: "A deep dive into the exciting new features and improvements in the latest React version...",
      author: "Jane Smith",
      date: "February 20, 2024",
      imageUrl: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?q=80&w=2940&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
    },
    {
      id: 3,
      title: "Mastering Tailwind CSS",
      excerpt: "Tips and tricks to become a Tailwind CSS power user and create stunning designs...",
      author: "Mike Johnson",
      date: "January 15, 2024",
      imageUrl: "https://images.unsplash.com/photo-1732017968601-f46d9badf229?q=80&w=3128&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
    }
  ]);

  return (
    <div>
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-center mb-12 text-gray-800">Latest Blogs</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogs.map(blog => (
            <BlogCard 
              key={blog.id}
              title={blog.title}
              excerpt={blog.excerpt}
              author={blog.author}
              date={blog.date}
              imageUrl={blog.imageUrl}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default HomePage;